import cv2
import numpy as np
import torch 
from matplotlib import pyplot as plt
#plt.rc('font', family='Times New Roman')
plt.figure(figsize=(11.5, 4.6))

x_list = range(1,11)
y_list_1 = [26.528,26.526,26.528,26.528,26.530,26.527,26.528,26.525,26.528,26.528]
y_list_2 = [24.368,24.376,24.362,24.362,24.355,24.371,24.361,24.372,24.374,24.366]
y_list_3 = [26.527,26.525,26.527,26.527,26.529,26.526,26.527,26.525,26.526,26.527]
y_list_4 = [24.367,24.379,24.342,24.355,24.355,24.367,24.360,24.375,24.378,24.364]
plt.subplot(1,2,1)
#plt.plot(x_list,np.log(hr_amplitude_list),linestyle="-", linewidth="2", markersize="16", marker=".", label='HR image',c='orange')
plt.plot(x_list,y_list_1,linestyle="-", linewidth="1.5", markersize="10", marker=".", label='Setting1',c='b')
#plt.plot(x_list,y_list_2,linestyle="-", linewidth="1", markersize="8", marker=".", label='Set2',c='orange')
plt.plot(x_list,y_list_3,linestyle="-", linewidth="1.5", markersize="10", marker=".", label='Setting2')
#plt.plot(x_list,y_list_4,linestyle="-", linewidth="1", markersize="8", marker=".", label='Set4')
plt.xlabel('Images',fontsize=12)
plt.ylabel('PSNR',fontsize=12)
#plt.title(r'$\sigma=0.2$'+', noise level=10',fontsize=15)
plt.title(r'$\lambda_{1},\lambda_{2}=0.2$'+', noise level=10',fontsize=12)
plt.legend()
plt.xlim([0.5,10.5])
plt.ylim([26.5,26.55])
x_label = ['I$_{1}$','I$_{2}$','I$_{3}$','I$_{4}$','I$_{5}$','I$_{6}$','I$_{7}$','I$_{8}$','I$_{9}$','I$_{10}$']
plt.xticks(ticks=x_list,labels=x_label,fontsize=14)
#plt.plot(np.log(lr_w_noise_amplitude_list),linestyle="-", linewidth="2", markersize="16", marker=".")
#plt.savefig('freq_energy_lr_hr.png',dpi=100)
plt.subplot(1,2,2)
#plt.plot(x_list,np.log(hr_amplitude_list),linestyle="-", linewidth="2", markersize="16", marker=".", label='HR image',c='orange')
#plt.plot(x_list,y_list_1,linestyle="-", linewidth="1.5", markersize="10", marker=".", label='Set1',c='b')
plt.plot(x_list,y_list_2,linestyle="-", linewidth="1.5", markersize="10", marker=".", label='Setting1',c='r')
#plt.plot(x_list,y_list_3,linestyle="-", linewidth="1.5", markersize="10", marker=".", label='Set3')
plt.plot(x_list,y_list_4,linestyle="-", linewidth="1.5", markersize="10", marker=".", label='Setting2',c='orange')
plt.xlabel('Images',fontsize=12)
plt.ylabel('PSNR',fontsize=12)
#plt.title(r'$\sigma=1.8$'+', noise level=20',fontsize=15)
plt.title(r'$\lambda_{1},\lambda_{2}=1.8$'+', noise level=20',fontsize=12)
plt.legend()
plt.xlim([0.5,10.5])
plt.ylim([24.3,24.4])
x_label = ['I$_{1}$','I$_{2}$','I$_{3}$','I$_{4}$','I$_{5}$','I$_{6}$','I$_{7}$','I$_{8}$','I$_{9}$','I$_{10}$']
plt.xticks(ticks=x_list,labels=x_label,fontsize=14)
plt.savefig('psnr_curve_deg_extract_from_other_w_label2.pdf',dpi=100)
plt.show()