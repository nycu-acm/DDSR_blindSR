# noise-free degradations with isotropic Gaussian blurs
#python test.py --test_only \
#               --dir_data='/mnt/HDD3/yuan/dataset' \
#               --data_test='Set14' \
#               --model='blindsr' \
#               --scale='4' \
#               --resume=600 \
#               --blur_type='iso_gaussian' \
#               --noise=0.0 \
#               --sig=1.2 #1.2

#python test.py --test_only \
#               --dir_data='/mnt/HDD3/yuan/dataset/test/' \
#               --data_test='GOPR0862_11_00' \
#               --model='model_modify_codebook_pca' \
#               --scale='4' \
#               --resume=600 \
#               --blur_type='aniso_gaussian' \
#               --noise=0.0 \
#               --theta=0 \
#               --lambda_1=0.2 \
#               --lambda_2=4.0 \
#               --n_GPUs=1 \
#               --save_result=True \
               ##--downsampler='s-fold'
               #--save_result=True \          
               ##--save_results=True 
               #'blindsr_modify_concat_with_fixed_representation' model_modify_codebook_pca 02 model_modify_codebook_pca_regressor CDSR model_modify_SRnetwork_cdsr blindsr_upper_bound_one_degradation  model_two_branch_fusion 
# general degradations with anisotropic Gaussian blurs and noises kernel1 (0.2 4.0   theta:0) kernel2 (3.0 4.0 theta:180) kernel3 (4.2,3.0 theta60) kernel4(0.000001,0.000001 0)
  
#cmd /k
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='DnCnn' --scale='4'  --blur_type='aniso_gaussian' --noise=20.0 --theta=0.0 --lambda_1=5.0 --lambda_2=5.0 --n_GPUs=1  --save_result=True --resume=5

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='DnCnn' --scale='4'  --blur_type='aniso_gaussian' --noise=30.0 --theta=0.0 --lambda_1=4.0 --lambda_2=4.0 --n_GPUs=1  --save_result=True --resume=5

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='DnCnn' --scale='4'  --blur_type='aniso_gaussian' --noise=30.0 --theta=0.0 --lambda_1=5.0 --lambda_2=5.0 --n_GPUs=1  --save_result=True --resume=5




python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set5' --model='model_ablation3' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=0.0 --lambda_1=2 --lambda_2=0.2 --n_GPUs=1  --save_result=True --resume=300

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set5' --model='model_ablation3' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=45 --lambda_1=2.5 --lambda_2=1.15 --n_GPUs=1  --save_result=True --resume=300

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set5' --model='model_ablation3' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=112.5 --lambda_1=3 --lambda_2=2.1 --n_GPUs=1  --save_result=True --resume=300

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set5' --model='model_ablation3' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=157.5 --lambda_1=3.5 --lambda_2=3.05 --n_GPUs=1  --save_result=True --resume=300

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set5' --model='model_ablation3' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=0.0 --lambda_1=4 --lambda_2=4 --n_GPUs=1  --save_result=True --resume=300



python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=5.0 --theta=0.0 --lambda_1=4 --lambda_2=4 --n_GPUs=1   --resume=585 
#--save_result=True

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='model_modify_SRnetwork_cdsr' --scale='4'  --blur_type='aniso_gaussian' --noise=20.0 --theta=0.0 --lambda_1=2 --lambda_2=0.2 --n_GPUs=1  --save_result=True --resume=615

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='model_modify_SRnetwork_cdsr' --scale='4'  --blur_type='aniso_gaussian' --noise=20.0 --theta=45 --lambda_1=2.5 --lambda_2=1.15 --n_GPUs=1  --save_result=True --resume=615

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='DnCnn' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=112.5 --lambda_1=3 --lambda_2=2.1 --n_GPUs=1  --save_result=True --resume=5

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_modify_SRnetwork_cdsr' --scale='4'  --blur_type='aniso_gaussian' --noise=20.0 --theta=157.5 --lambda_1=3.5 --lambda_2=3.05 --n_GPUs=1  --save_result=True --resume=615

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='DnCnn' --scale='4'  --blur_type='aniso_gaussian' --noise=5.0 --theta=0.0 --lambda_1=4 --lambda_2=4 --n_GPUs=1  --save_result=True --resume=5


python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='DnCnn' --scale='2'  --blur_type='aniso_gaussian' --noise=10.0 --theta=0.0 --lambda_1=1 --lambda_2=0.2 --n_GPUs=1  --save_result=True --resume=10

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='DnCnn' --scale='2'  --blur_type='aniso_gaussian' --noise=10.0 --theta=45 --lambda_1=1.25 --lambda_2=0.65 --n_GPUs=1  --save_result=True --resume=10

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='DnCnn' --scale='2'  --blur_type='aniso_gaussian' --noise=10.0 --theta=112.5 --lambda_1=1.5 --lambda_2=1.1 --n_GPUs=1  --save_result=True --resume=10

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='DnCnn' --scale='2'  --blur_type='aniso_gaussian' --noise=10.0 --theta=157.5 --lambda_1=1.75 --lambda_2=1.55 --n_GPUs=1  --save_result=True --resume=10

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='DnCnn' --scale='2'  --blur_type='aniso_gaussian' --noise=10.0 --theta=0.0 --lambda_1=2 --lambda_2=2 --n_GPUs=1  --save_result=True --resume=10


python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='model_modify_codebook_pca_regressor' --scale='2'  --blur_type='aniso_gaussian' --noise=20.0 --theta=0.0 --lambda_1=1 --lambda_2=0.2 --n_GPUs=1  --save_result=True --resume=570

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='model_modify_codebook_pca_regressor' --scale='2'  --blur_type='aniso_gaussian' --noise=20.0 --theta=45 --lambda_1=1.25 --lambda_2=0.65 --n_GPUs=1  --save_result=True --resume=570

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='model_modify_codebook_pca_regressor' --scale='2'  --blur_type='aniso_gaussian' --noise=20.0 --theta=112.5 --lambda_1=1.5 --lambda_2=1.1 --n_GPUs=1  --save_result=True --resume=570

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='model_modify_codebook_pca_regressor' --scale='2'  --blur_type='aniso_gaussian' --noise=20.0 --theta=157.5 --lambda_1=1.75 --lambda_2=1.55 --n_GPUs=1  --save_result=True --resume=570

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Urban100' --model='model_modify_codebook_pca_regressor' --scale='2'  --blur_type='aniso_gaussian' --noise=20.0 --theta=0.0 --lambda_1=2 --lambda_2=2 --n_GPUs=1  --save_result=True --resume=570


python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set5' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=0.0 --lambda_1=2 --lambda_2=0.2 --n_GPUs=1  --save_result=True --resume=585

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set5' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=45 --lambda_1=2.5 --lambda_2=1.15 --n_GPUs=1  --save_result=True --resume=585

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set5' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=112.5 --lambda_1=3 --lambda_2=2.1 --n_GPUs=1  --save_result=True --resume=585

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set5' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=157.5 --lambda_1=3.5 --lambda_2=3.05 --n_GPUs=1  --save_result=True --resume=585

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set5' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=0.0 --lambda_1=4 --lambda_2=4 --n_GPUs=1  --save_result=True --resume=585



python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=0.0 --lambda_1=2 --lambda_2=0.2 --n_GPUs=1  --save_result=True --resume=600
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=22.5 --lambda_1=2.25 --lambda_2=0.675 --n_GPUs=1  --save_result=True --resume=600
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=45 --lambda_1=2.5 --lambda_2=1.15 --n_GPUs=1  --save_result=True --resume=600
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=90 --lambda_1=2.75 --lambda_2=1.625 --n_GPUs=1  --save_result=True --resume=600
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=112.5 --lambda_1=3 --lambda_2=2.1 --n_GPUs=1  --save_result=True --resume=600
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=135 --lambda_1=3.25 --lambda_2=2.575 --n_GPUs=1  --save_result=True --resume=600
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=157.5 --lambda_1=3.5 --lambda_2=3.05 --n_GPUs=1  --save_result=True --resume=585
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=180 --lambda_1=3.75 --lambda_2=3.525 --n_GPUs=1  --save_result=True --resume=600
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=0.0 --lambda_1=4 --lambda_2=4 --n_GPUs=1  --save_result=True --resume=600

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4'  --blur_type='aniso_gaussian' --noise=0.0 --theta=0.0 --lambda_1=0.2 --lambda_2=4.0 --n_GPUs=1  --save_result=True --resume=480
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4'  --blur_type='aniso_gaussian' --noise=10.0 --theta=0.0 --lambda_1=0.2 --lambda_2=4.0 --n_GPUs=1  --save_result=True --resume=480
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4'  --blur_type='aniso_gaussian' --noise=20.0 --theta=0.0 --lambda_1=0.2 --lambda_2=4.0 --n_GPUs=1  --save_result=True --resume=480
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4'  --blur_type='aniso_gaussian' --noise=5.0 --theta=0.0 --lambda_1=0.2 --lambda_2=4.0 --n_GPUs=1  --save_result=True --resume=480
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4'  --blur_type='aniso_gaussian' --noise=15.0 --theta=0.0 --lambda_1=0.2 --lambda_2=4.0 --n_GPUs=1  --save_result=True --resume=480

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4'  --blur_type='aniso_gaussian' --noise=0.0 --theta=180.0 --lambda_1=3.0 --lambda_2=4.0 --n_GPUs=1  --save_result=True --resume=480
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --blur_type='aniso_gaussian' --noise=10.0 --theta=180.0 --lambda_1=3.0 --lambda_2=4.0 --n_GPUs=1  --save_result=True --resume=480 
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --blur_type='aniso_gaussian' --noise=20.0 --theta=180.0 --lambda_1=3.0 --lambda_2=4.0 --n_GPUs=1  --save_result=True --resume=480 
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --blur_type='aniso_gaussian' --noise=5.0 --theta=180.0 --lambda_1=3.0 --lambda_2=4.0 --n_GPUs=1   --save_result=True --resume=480 
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --blur_type='aniso_gaussian' --noise=15.0 --theta=180.0 --lambda_1=3.0 --lambda_2=4.0 --n_GPUs=1  --save_result=True --resume=480

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --resume=480 --blur_type='aniso_gaussian' --noise=0.0 --theta=60.0 --lambda_1=4.2 --lambda_2=3.0 --n_GPUs=1  --save_result=True
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --blur_type='aniso_gaussian' --noise=10.0 --theta=60.0 --lambda_1=4.2 --lambda_2=3.0 --n_GPUs=1  --save_result=True --resume=485
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --resume=480 --blur_type='aniso_gaussian' --noise=20.0 --theta=60.0 --lambda_1=4.2 --lambda_2=3.0 --n_GPUs=1  --save_result=True
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --resume=480 --blur_type='aniso_gaussian' --noise=5.0 --theta=60.0 --lambda_1=4.2 --lambda_2=3.0 --n_GPUs=1  --save_result=True
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --resume=480 --blur_type='aniso_gaussian' --noise=15.0 --theta=60.0 --lambda_1=4.2 --lambda_2=3.0 --n_GPUs=1  --save_result=True

python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --resume=430 --blur_type='aniso_gaussian' --noise=0.0 --theta=0.0 --lambda_1=0.000001 --lambda_2=0.000001 --n_GPUs=1  --save_result=True
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --resume=430 --blur_type='aniso_gaussian' --noise=10.0 --theta=0.0 --lambda_1=0.000001 --lambda_2=0.000001 --n_GPUs=1  --save_result=True
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --resume=430 --blur_type='aniso_gaussian' --noise=20.0 --theta=0.0 --lambda_1=0.000001 --lambda_2=0.000001 --n_GPUs=1  --save_result=True
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --resume=430 --blur_type='aniso_gaussian' --noise=5.0 --theta=0.0 --lambda_1=0.000001 --lambda_2=0.000001 --n_GPUs=1  --save_result=True
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_two_branch_fusion' --scale='4' --resume=430 --blur_type='aniso_gaussian' --noise=15.0 --theta=0.0 --lambda_1=0.000001 --lambda_2=0.000001 --n_GPUs=1  --save_result=True

 
python test.py --test_only --dir_data='/mnt/HDD3/yuan/dataset/test/' --data_test='Set14' --model='model_modify_codebook_pca_regressor' --scale='4'  --blur_type='aniso_gaussian' --noise=0.0 --theta=135.0 --lambda_1=3.2 --lambda_2=1.5 --n_GPUs=1   --resume=585 