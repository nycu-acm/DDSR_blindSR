import cv2
import glob
filePath = '/mnt/HDD8/yuan/results_lr/lr_x4_w_n10/' #'/mnt/HDD8/yuan/results_freq_kernel07_contrastive_codebook_pca10/B100/*/'
test_list = sorted(glob.glob(filePath+"/*.png"))
#print(test_list)
for filename in test_list:
  ndarr = cv2.imread(filename)
  img = cv2.imwrite('{}.png'.format(filename),cv2.cvtColor(ndarr, cv2.COLOR_RGB2BGR))