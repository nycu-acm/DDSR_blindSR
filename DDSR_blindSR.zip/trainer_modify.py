import os
import utility
import torch
from decimal import Decimal
import torch.nn.functional as F
from utils import util
import csv
import lpips
from tensorboardX import SummaryWriter
import torch
from pytorch_wavelets import DWTForward, DWTInverse
import cv2
import numpy as np
import torch.nn as nn

# extract kernel and noise seperately
# non end-to-end train
# first train the degradation model 300 epochs
# then train the SR network 300 epoch
# kernel encoder: postive sample (same kernel) negative sample (differnet kernel) 
class Trainer():
    def __init__(self, args, loader, my_model, my_loss, ckp):
        self.args = args
        self.scale = args.scale

        self.ckp = ckp
        self.loader_train = loader.loader_train
        self.loader_test = loader.loader_test
        self.model = my_model
        self.model_G = torch.nn.DataParallel(self.model.get_model().G, range(self.args.n_GPUs))
        self.model_E_kernel = torch.nn.DataParallel(self.model.get_model().E_kernel, range(self.args.n_GPUs))
        self.model_E_noise = torch.nn.DataParallel(self.model.get_model().E_noise, range(self.args.n_GPUs))
        #self.patch_discriminator = torch.nn.DataParallel(self.model.get_model().patch_discriminator, range(self.args.n_GPUs))
        self.loss = my_loss
        self.contrast_loss = torch.nn.CrossEntropyLoss().cuda()
        self.optimizer = utility.make_optimizer(args, self.model)
        #self.optimizer_D = utility.make_optimizer(args, self.patch_discriminator)
        self.scheduler = utility.make_scheduler(args, self.optimizer)
        tensorboard_folder = '/mnt/HDD2/yuan/DASR/tensorboard_freq_kernel07_codebook_pca05/'
        self.tb_logger_1 = SummaryWriter(log_dir= os.path.join(tensorboard_folder , "loss_constrastive"))
        self.tb_logger_2 = SummaryWriter(log_dir= os.path.join(tensorboard_folder , "loss_sr"))
        self.tb_logger_3 = SummaryWriter(log_dir= os.path.join(tensorboard_folder , "loss_gan"))
        self.loss_fn_alex = lpips.LPIPS(net='alex').cuda() # best forward scores
        self.xfm = DWTForward(J=1, mode='zero', wave='haar').cuda()   # Accepts all wave types available to PyWavelets
        self.ifm = DWTInverse( mode='zero', wave='haar').cuda()
        #self.GAN_loss_layer = GANLoss().cuda()
        self.total_variation_loss = L_TV()
        #self.criterionGAN = self.GAN_loss_layer.forward
        if self.args.load != '.':
            self.optimizer.load_state_dict(
                torch.load(os.path.join(ckp.dir, 'optimizer.pt'))
            )
            for _ in range(len(ckp.log)): self.scheduler.step()
        if args.resume>0:
          #self.iteration = args.resume*len(self.loader_train.dataset)/self.args.batch_size
          self.iteration = args.resume*round(31050/self.args.batch_size+0.5)
        else:
          self.iteration = 0
    def train(self):
        self.scheduler.step()
        self.loss.step()
        epoch = self.scheduler.last_epoch + 1

        # lr stepwise
        if epoch <= self.args.epochs_encoder:
            lr = self.args.lr_encoder #* (self.args.gamma_encoder ** (epoch // self.args.lr_decay_encoder))
            for param_group in self.optimizer.param_groups:
                param_group['lr'] = lr
        else:
            lr = self.args.lr_sr *0.5* (self.args.gamma_sr ** ((epoch - self.args.epochs_encoder) // self.args.lr_decay_sr))
            for param_group in self.optimizer.param_groups:
                param_group['lr'] = lr

        self.ckp.write_log('[Epoch {}]\tLearning rate: {:.2e}'.format(epoch, Decimal(lr)))
        self.loss.start_log()
        self.model.train()


        degrade = util.my_SRMDPreprocessing(
            self.scale[0],
            kernel_size=self.args.blur_kernel,
            blur_type=self.args.blur_type,
            sig_min=self.args.sig_min,
            sig_max=self.args.sig_max,
            lambda_min=self.args.lambda_min,
            lambda_max=self.args.lambda_max,
            noise=self.args.noise,
        )
        timer = utility.timer()
        losses_contrast_kernel, losses_contrast_noise, losses_sr, losses_g, losses_d, losses_tv,losses_feature_matching = utility.AverageMeter(), utility.AverageMeter(), utility.AverageMeter(), utility.AverageMeter(), utility.AverageMeter(), utility.AverageMeter(), utility.AverageMeter()

        for batch, (hr, _, idx_scale) in enumerate(self.loader_train):
            hr = hr.cuda()                              # b, n, c, h, w
            lr_blured_kernel, lr_no_blured, lr_blured_kernel_noise_1,lr_no_blured_noise,lr_blured_kernel_noise_2, b_kernel = degrade(hr)
            #print(hr.shape) 
            Yl, Yh = self.xfm(lr_blured_kernel_noise_1[:,0,...]) # positive sample with noise
            #Yl, Yh = self.xfm(lr_blured_kernel[:,0,...])
            Yh1= Yh[0][:,0,...] #HL
            Yh2= Yh[0][:,1,...] #LH
            Yh3= Yh[0][:,2,...] #HH\
            #lr_blured_kernel_noise_1 =torch.cat((Yl,Yh1,Yh2,Yh3),1)
            lr_blured_kernel_noise_1_01 =torch.cat((Yh1,Yh2,Yh3),1)
            #lr_blured_kernel_noise_1 = Yh3
            lr_blured_kernel_noise_1_01 = lr_blured_kernel_noise_1_01.detach()
            Yl, Yh = self.xfm(lr_blured_kernel[:,1,...]) # positive sample with noise
            #Yl, Yh = self.xfm(lr_blured_kernel[:,1,...])
            Yh1= Yh[0][:,0,...]
            Yh2= Yh[0][:,1,...]
            Yh3= Yh[0][:,2,...]
            #lr_blured_kernel_noise_2 =torch.cat((Yl,Yh1,Yh2,Yh3),1)
            lr_blured_kernel_noise_2_02 = torch.cat((Yh1,Yh2,Yh3),1)
            #lr_blured_kernel_noise_2 = Yh3
            lr_blured_kernel_noise_2_02 = lr_blured_kernel_noise_2_02.detach()
            #print(lr_blured_kernel_noise_2.shape)       
            if batch %2==0:
              tmp = lr_blured_kernel_noise_1_01
              lr_blured_kernel_noise_1_01 = lr_blured_kernel_noise_2_02
              lr_blured_kernel_noise_2_02 = tmp
            
            Yl, Yh = self.xfm(lr_blured_kernel_noise_2[:,0,...])
            Yh1= Yh[0][:,0,...]
            Yh2= Yh[0][:,1,...]
            Yh3= Yh[0][:,2,...]
            lr_blured_kernel_noise_2_01 = torch.cat((Yh1,Yh2,Yh3),1)
            lr_blured_kernel_noise_2_01 = lr_blured_kernel_noise_2_01.detach()
            
            Yl, Yh = self.xfm(lr_no_blured_noise[:,1,...])
            Yh1= Yh[0][:,0,...]
            Yh2= Yh[0][:,1,...]
            Yh3= Yh[0][:,2,...]
            lr_no_blured_noise_2_02 = torch.cat((Yh1,Yh2,Yh3),1)
            lr_no_blured_noise_2_02 = lr_no_blured_noise_2_02.detach()
            lr_q = lr_blured_kernel_noise_2_01
            lr_k = lr_no_blured_noise_2_02
            if batch %2==0:
              tmp = lr_q
              lr_q = lr_k
              lr_k = tmp                                        
            self.optimizer.zero_grad()
            timer.tic()
            # forward
            ## train degradation encoder
            if epoch <= self.args.epochs_encoder:
                _, output_kernel, target_kernel = self.model_E_kernel(im_q=lr_blured_kernel_noise_1_01, im_k=lr_blured_kernel_noise_2_02)
                _, output_noise, target_noise = self.model_E_noise(im_q=lr_q, im_k=lr_k)            
                #_, output_kernel, target_kernel = self.model_E_kernel(im_q=lr_blured_kernel[:,0,...], im_k=lr_blured_kernel[:,1,...])
                #_, output_noise, target_noise = self.model_E_noise(im_q=lr_no_blured_noise[:,0,...], im_k=lr_no_blured_noise[:,1,...])
                # embedding(degradation representation of query), logits(negative sample predict), labels(for negative sample: 0 )
                loss_constrast_kernel = self.contrast_loss(output_kernel, target_kernel)
                loss_constrast_noise = self.contrast_loss(output_noise, target_noise)
                loss = loss_constrast_kernel + loss_constrast_noise
                #loss = loss_constrast_noise
                losses_contrast_kernel.update(loss_constrast_kernel.item())
                losses_contrast_noise.update(loss_constrast_noise.item())
                if self.iteration %100 ==0:
                  self.tb_logger_1.add_scalar( "L_kernel" , loss_constrast_kernel.item() , self.iteration)
                  self.tb_logger_1.add_scalar( "L_noise" , loss_constrast_noise.item() , self.iteration)
            ## train the whole network
            elif epoch <= self.args.epochs_encoder+350:
              #self.set_requires_grad(self.patch_discriminator, False)
              self.model_E_kernel.eval()
              self.model_E_noise.eval()
              with torch.no_grad():
                embeding_1 = self.model_E_kernel(im_q=lr_blured_kernel_noise_1_01, im_k=lr_blured_kernel_noise_2_02)
                embeding_2 = self.model_E_noise(im_q=lr_q, im_k=lr_k)
                              
              sr = self.model_G(lr_blured_kernel_noise_2[:,0,...], embeding_1, embeding_2)
              loss_SR = self.loss(sr, hr[:,0,...])
              loss = loss_SR
              if self.iteration %100 == 0:
                self.tb_logger_2.add_scalar( "L_SR" , loss_SR.item() , self.iteration)
              losses_sr.update(loss_SR.item())              
            else:
              Yl, Yh = self.xfm(lr_blured_kernel_noise_2[:,1,...]) # positive sample with noise
              #Yl, Yh = self.xfm(lr_blured_kernel[:,1,...])
              Yh1= Yh[0][:,0,...]
              Yh2= Yh[0][:,1,...]
              Yh3= Yh[0][:,2,...]
              #lr_blured_kernel_noise_2 =torch.cat((Yl,Yh1,Yh2,Yh3),1)
              lr_blured_kernel_noise_2_wavelet = torch.cat((Yh1,Yh2,Yh3),1)
              lr_blured_kernel_noise_2_wavelet = lr_blured_kernel_noise_2_wavelet.detach()            
              embeding_1, output_kernel, target_kernel = self.model_E_kernel(im_q=lr_blured_kernel_noise_2_wavelet, im_k=lr_blured_kernel_noise_2_02)
              embeding_2, output_noise, target_noise = self.model_E_noise(im_q=lr_blured_kernel_noise_2_wavelet, im_k=lr_k)
              sr = self.model_G(lr_blured_kernel_noise_2[:,0,...], embeding_1, embeding_2)            
              loss_SR = self.loss(sr, hr[:,0,...])
              loss_constrast_kernel = self.contrast_loss(output_kernel, target_kernel)
              loss_constrast_noise = self.contrast_loss(output_noise, target_kernel)
              loss = loss_SR + loss_constrast_kernel + loss_constrast_noise #+ loss_g  + loss_feature_matching
              if self.iteration %100 == 0:
                self.tb_logger_2.add_scalar( "L_SR" , loss_SR.item() , self.iteration)
                self.tb_logger_1.add_scalar( "L_kernel" , loss_constrast_kernel.item() , self.iteration)
                self.tb_logger_1.add_scalar( "L_noise" , loss_constrast_noise.item() , self.iteration)
              losses_sr.update(loss_SR.item())
              losses_contrast_kernel.update(loss_constrast_kernel.item())
              losses_contrast_noise.update(loss_constrast_noise.item())
            # backward
            loss.backward()
            self.optimizer.step()             
            timer.hold()
            self.iteration += 1
            if epoch <= self.args.epochs_encoder:
                if (batch + 1) % self.args.print_every == 0:
                    self.ckp.write_log(
                        'Epoch: [{:03d}][{:04d}/{:04d}]\t'
                        'Loss [contrastive loss kernel: {:.3f}]|contrastive loss noise: {:.3f}]\t'
                        'Time [{:.1f}s]'.format(
                            epoch, (batch + 1) * self.args.batch_size, len(self.loader_train.dataset),
                            losses_contrast_kernel.avg,
                            losses_contrast_noise.avg,
                            timer.release()
                        ))
            else:
                if (batch + 1) % self.args.print_every == 0:
                    self.ckp.write_log(
                        'Epoch: [{:04d}][{:04d}/{:04d}]\t'
                        'Loss [contrastive loss kernel: {:.3f}]|contrastive loss noise: {:.3f}]\t'
                        'Loss [SR loss:{:.3f}\t'
                        'Time [{:.1f}s]'.format(
                            epoch, (batch + 1) * self.args.batch_size, len(self.loader_train.dataset),
                            losses_contrast_kernel.avg,
                            losses_contrast_noise.avg,                                                       
                            losses_sr.avg,
                            timer.release(),
                        ))
            
                '''if (batch + 1) % self.args.print_every == 0:
                    self.ckp.write_log(
                        'Epoch: [{:04d}][{:04d}/{:04d}]\t'
                        'Loss [contrastive loss kernel: {:.3f}]|contrastive loss noise: {:.3f}]\t'
                        'Loss [SR loss:{:.3f}]\t'
                        'Loss [GAN: Gen loss{:.3f}|Dis loss{:.3f} ]\t'
                        'Loss [fea match loss{:.3f}]\t'
                        'Time [{:.1f}s]'.format(
                            epoch, (batch + 1) * self.args.batch_size, len(self.loader_train.dataset),
                            losses_contrast_kernel.avg,
                            losses_contrast_noise.avg,
                            losses_sr.avg,
                            losses_g.avg,losses_d.avg,
                            losses_feature_matching.avg,
                            timer.release(),
                        ))'''

        self.loss.end_log(len(self.loader_train))

        # save model
        target = self.model.get_model()
        model_dict = target.state_dict()
        keys = list(model_dict.keys())
        #for key in keys:
            #if 'E.encoder_k' in key or 'queue' in key:
            #if 'E_noise' in key or 'G' in key:
                #del model_dict[key]
        torch.save(
            model_dict,
            #os.path.join(self.ckp.dir, 'model_freq_kernel07_codebook_pca05', 'model_{}.pt'.format(epoch))
            os.path.join('/mnt/HDD8/yuan/', 'model_freq_kernel07_codebook_pca05', 'model_{}.pt'.format(epoch))
          )

    def test(self):
        self.ckp.write_log('\nEvaluation:')
        self.ckp.add_log(torch.zeros(1, len(self.scale)))
        # model __init__ line 101
        '''if self.args.blur_type == 'iso_gaussian':
          dir = './experiment/blindsr_x' + str(int(self.scale[0])) + '_bicubic_iso'
        elif self.args.blur_type == 'aniso_gaussian':
          dir = './experiment/blindsr_x' + str(int(self.scale[0])) + '_bicubic_aniso'
        self.model.load_state_dict(torch.load(dir + '/model_new/model_' + str(self.args.resume) + '.pt'), strict=False)'''
        
        self.model.eval()

        timer_test = utility.timer()
        str_ = self.args.blur_type.split("_")[0]
        with open('./experiment/blindsr_x' + str(int(self.scale[0]))+'_bicubic_'+ str_+'/extract_separate_evaluate.csv','a') as f:
          writer = csv.writer(f)
          writer.writerow(['scale','noise','theta','lambda_1','lambda_2'])          
          writer.writerow([self.scale[0],self.args.noise,self.args.theta,self.args.lambda_1,self.args.lambda_2])
        with torch.no_grad():
            for idx_scale, scale in enumerate(self.scale):
                self.loader_test.dataset.set_scale(idx_scale)
                eval_psnr = 0
                eval_ssim = 0
                eval_lpips = 0
                degrade = util.SRMDPreprocessing(
                    self.scale[0],
                    kernel_size=self.args.blur_kernel,
                    blur_type=self.args.blur_type,
                    sig=self.args.sig,
                    lambda_1=self.args.lambda_1,
                    lambda_2=self.args.lambda_2,
                    theta=self.args.theta,
                    noise=self.args.noise
                )            
                '''degrade_kernel_noise = util.my_SRMDPreprocessing(
                    self.scale[0],
                    kernel_size=self.args.blur_kernel,
                    blur_type=self.args.blur_type,
                    sig_min=self.args.sig_min,
                    sig_max=self.args.sig_max,
                    lambda_min=self.args.lambda_min,
                    lambda_max=self.args.lambda_max,
                    noise=self.args.noise
                )'''
                for idx_img, (hr, filename, _) in enumerate(self.loader_test):
                    hr = hr.cuda()                      # b, 1, c, h, w
                    hr = hr[:,:,[2,1,0],...]
                    hr = self.crop_border(hr, scale)
                    lr, kernel = degrade(hr, random=False)   # b, 1, c, h, w                   
                    hr = hr[:, 0, ...]                  # b, c, h, w
                    Yl, Yh = self.xfm(lr[:,0,...]) # positive sample with noise
                    Y = self.ifm((Yl,Yh))
                    #Yl, Yh = self.xfm(lr_blured_kernel[:,0,...])
                    Yh1= Yh[0][:,0,...] #HL
                    Yh2= Yh[0][:,1,...] #LH
                    Yh3= Yh[0][:,2,...] #HH
                    #lr_blured_kernel_noise_1 =torch.cat((Yl,Yh1,Yh2,Yh3),1)
                    lr_wavelet =torch.cat((Yh1,Yh2,Yh3),1)
                    # inference
                    timer_test.tic()
                    #sr = self.model(lr[:, 0, ...])
                    sr = self.model([lr[:, 0, ...], lr_wavelet])
                    #sr,kernel_fea = self.model([lr[:, 0, ...]])
                    #kernel_mean_val = torch.mean(torch.abs(kernel_fea))
                    #sr = self.model([lr[:, 0, ...], lr[:, 0, ...]])
                    timer_test.hold()

                    sr = utility.quantize(sr, self.args.rgb_range)
                    hr = utility.quantize(hr, self.args.rgb_range)
                    d_lpips = self.loss_fn_alex(sr, hr)
                    eval_lpips += d_lpips.item()
                    # metrics
                    psnr_ = utility.calc_psnr(
                        sr, hr, scale, self.args.rgb_range,
                        benchmark=self.loader_test.dataset.benchmark
                    )
                    eval_psnr += psnr_ 
                    ssim_ = utility.calc_ssim(
                        sr, hr, scale,
                        benchmark=self.loader_test.dataset.benchmark
                    )
                    eval_ssim += ssim_
                    print(filename,'PSNR:{:.3f} SSIM{:.4f} LPIPS{:.4f}'.format(psnr_,ssim_,d_lpips.item()))
                    str_ = self.args.blur_type.split("_")[0]
                    with open('./experiment/blindsr_x' + str(int(self.scale[0]))+'_bicubic_'+ str_+'/extract_separate_evaluate.csv','a') as f:
                          writer = csv.writer(f)
                          writer.writerow([filename,psnr_,ssim_,d_lpips.item()])                   
                    # save results
                    if self.args.save_results:
                        save_list = [sr]
                        filename = filename[0]
                        self.ckp.save_results(filename, save_list, scale,self.args.data_test,self.args.lambda_1,self.args.lambda_2,self.args.theta,self.args.noise)
                        #self.ckp.save_results(filename, [lr[:,0,...]], scale,self.args.data_test,self.args.lambda_1,self.args.lambda_2,self.args.theta,self.args.noise)
                self.ckp.save_results('kernel', [kernel], scale,self.args.data_test,self.args.lambda_1,self.args.lambda_2,self.args.theta,self.args.noise,False)
                with open('./experiment/blindsr_x' + str(int(self.scale[0]))+'_bicubic_'+ str_+'/extract_separate_evaluate.csv','a') as f:
                   writer = csv.writer(f)
                   writer.writerow(['Average',eval_psnr/len(self.loader_test),eval_ssim/len(self.loader_test),eval_lpips/len(self.loader_test)])   
                self.ckp.log[-1, idx_scale] = eval_psnr / len(self.loader_test)
                self.ckp.write_log(
                    '[Epoch {}---{} x{}]\tPSNR: {:.3f} SSIM: {:.4f} LPIPS:{:.4f}'.format(
                        self.args.resume,
                        self.args.data_test,
                        scale,
                        eval_psnr / len(self.loader_test),
                        eval_ssim / len(self.loader_test),
                        eval_lpips/ len(self.loader_test)
                    ))
                print('kernel:[{},{}] noise level:[{}]'.format(self.args.lambda_1,self.args.lambda_2,self.args.noise))

    def crop_border(self, img_hr, scale):
        b, n, c, h, w = img_hr.size()

        img_hr = img_hr[:, :, :, :int(h//scale*scale), :int(w//scale*scale)]

        return img_hr

    def terminate(self):
        if self.args.test_only:
            self.test()
            return True
        else:
            epoch = self.scheduler.last_epoch + 1
            return epoch >= self.args.epochs_encoder + self.args.epochs_sr
##
    def set_requires_grad(self, model_names, requires_grad):
        for v in model_names.parameters():
            v.requires_grad = requires_grad
'''import os
import utility
import torch
from decimal import Decimal
import torch.nn.functional as F
from utils import util
from torch.utils.data import Dataset,DataLoader
import cv2
import glob
import random
from PIL import Image
import numpy as np
from model.blindsr import BlindSR
#from data import multiscalesrdata.my_SRData as my_SRData
from data import common
from tensorboardX import SummaryWriter

os.environ['CUDA_VISIBLE_DEVICES'] = '0'

def populate_train_list(lowlight_images_path):
	file_label = os.listdir(lowlight_images_path)[0].split('.')[-1]
	image_list_lowlight = glob.glob(lowlight_images_path + "*."+file_label)
	train_list = image_list_lowlight    
	random.shuffle(train_list)
	return train_list
 
class lowlight_loader(Dataset):

	def __init__(self, lowlight_images_path):

		self.train_list = populate_train_list(lowlight_images_path) 
		self.size = 256

		self.data_list = self.train_list
		print("Total training examples:", len(self.train_list))


		

	def __getitem__(self, index):

		data_lowlight_path = self.data_list[index]
		
		data_lowlight = Image.open(data_lowlight_path)
		
		#data_lowlight = data_lowlight.resize((self.size,self.size), Image.ANTIALIAS)

		data_lowlight = (np.asarray(data_lowlight)/255.0) 
		data_lowlight = torch.from_numpy(data_lowlight).float()
		data_lowlight = data_lowlight.permute(2,0,1)
		data_lowlight = data_lowlight[None,:,:,:]
		filename = data_lowlight_path.split("/")[-1]
   
		return (data_lowlight,filename)

	def __len__(self):
		return len(self.data_list)


class my_SRData(Dataset):
    def __init__(self, images_path, scale):
      self.train_list = populate_train_list(images_path) 
      # self.size = 256
      self.scale = scale
      self.data_list = self.train_list
      print("Total training examples:", len(self.train_list))
    # Below functions as used to prepare images

    def __getitem__(self, idx):
    
    
      data_path = self.data_list[idx]
		
      hr = Image.open(data_path)

      hr = (np.asarray(hr)/255.0)
      [hr_0, hr_1] = self.get_patch(hr)
      hr_0 = np.ascontiguousarray(hr_0)      
      hr_0 = torch.from_numpy(hr_0).float()
      hr_0 = hr_0.permute(2,0,1)
      hr_1 = np.ascontiguousarray(hr_1)
      hr_1 = torch.from_numpy(hr_1).float()
      hr_1 = hr_1.permute(2,0,1)
      hr = torch.stack((hr_0, hr_1), dim = 0)
      filename = data_path.split("/")[-1]
      return (hr,filename)


    def __len__(self):
        return len(self.data_list)

    def get_patch(self, hr):
        #scale = self.scale[self.idx_scale]
        scale = self.scale[0]
        #if self.train:
        out = []
        #data augmentation: rotate or flip
        hr = common.augment(hr) #if not self.args.no_augment else hr

        # extract two patches from each image
        for _ in range(2):
          hr_patch = common.get_patch(
                    hr,
                    patch_size=48, #self.args.patch_size,
                    scale=scale
                )
          out.append(hr_patch)
        #else:
            #out = [hr]
        return out



class Trainer():
    #def __init__(self, args, loader, my_model, my_loss, ckp):
    def __init__(self, args, my_model, my_loss, ckp):
        self.args = args
        self.scale = args.scale
        self.batch_size =25
        self.ckp = ckp
        #self.loader_train = loader.loader_train
        #self.loader_test = loader.loader_test
        #train_dataset = lowlight_loader("/mnt/HDD3/yuan/dataset/Set14/original/")
        train_dataset = my_SRData('/home/user/DISK2/datasets/DF2K/', self.scale)
        self.loader_train = DataLoader(train_dataset, batch_size=self.batch_size, shuffle=True, num_workers=4, pin_memory=True)        
        test_dataset = lowlight_loader("/home/user/DISK2/datasets/Set14/original/")		
        self.loader_test = DataLoader(test_dataset, batch_size=1, shuffle=True, num_workers=4, pin_memory=True)
        self.model = my_model.cuda()
        #self.model_E = torch.nn.DataParallel(self.model.get_model().E, range(self.args.n_GPUs))
        #self.model_E_kernel = self.model.get_model().E_kernel #torch.nn.DataParallel(self.model.get_model().E, range(self.args.n_GPUs))
        #self.model_E_noise = self.model.get_model().E_noise
        self.model_E_kernel = self.model.E_kernel #torch.nn.DataParallel(self.model.get_model().E, range(self.args.n_GPUs))
        self.model_E_noise = self.model.E_noise
        self.loss = my_loss
        self.contrast_loss = torch.nn.CrossEntropyLoss().cuda()
        self.optimizer = utility.make_optimizer(args, self.model)
        self.scheduler = utility.make_scheduler(args, self.optimizer)
        #parser.add_argument('--tensorboard_folder', type= str ,default ="tb_logger/zero_dce_fusion_fivek_discriminator_set5/")
        tensorboard_folder = '/home/user/DISK2/yuan/DASR/tensorboard/'
        self.tb_logger_1 = SummaryWriter(log_dir= os.path.join(tensorboard_folder , "loss_constrastive"))
        self.tb_logger_2 = SummaryWriter(log_dir= os.path.join(tensorboard_folder , "loss_sr"))
        #print(os.path.join(tensorboard_folder , "loss_sr"))
        if self.args.load != '.':
            self.optimizer.load_state_dict(
                torch.load(os.path.join(ckp.dir, 'optimizer.pt'))
            )
            for _ in range(len(ckp.log)): self.scheduler.step()

    def train(self):
        self.scheduler.step()
        self.loss.step()
        epoch = self.scheduler.last_epoch + 1

        # lr stepwise
        if epoch <= self.args.epochs_encoder:
            lr = self.args.lr_encoder * (self.args.gamma_encoder ** (epoch // self.args.lr_decay_encoder))
            for param_group in self.optimizer.param_groups:
                param_group['lr'] = lr
        else:
            lr = self.args.lr_sr * (self.args.gamma_sr ** ((epoch - self.args.epochs_encoder) // self.args.lr_decay_sr))
            for param_group in self.optimizer.param_groups:
                param_group['lr'] = lr

        self.ckp.write_log('[Epoch {}]\tLearning rate: {:.2e}'.format(epoch, Decimal(lr)))
        self.loss.start_log()
        self.model.train()

        degrade_kernel_noise = util.my_SRMDPreprocessing(
            self.scale[0],
            kernel_size=self.args.blur_kernel,
            blur_type=self.args.blur_type,
            sig_min=self.args.sig_min,
            sig_max=self.args.sig_max,
            lambda_min=self.args.lambda_min,
            lambda_max=self.args.lambda_max,
            noise=self.args.noise
        )

        timer = utility.timer()
        losses_contrast, losses_sr = utility.AverageMeter(), utility.AverageMeter()
        #for idx_img, (hr, filename, _) in enumerate(self.loader_test):
        #for batch, (hr, _, idx_scale) in enumerate(self.loader_train):
        iteration = 0 +(epoch-1)*len(self.loader_train.dataset)/self.batch_size #142=3550/25
        for batch, (hr, filename) in enumerate(self.loader_train):
            hr = hr.cuda()                              # b, n, c, h, w (batch size,(n=2 query & key patch), c, h, w)
            hr = hr*255
            lr_same_kernel, lr_different_kernel = degrade_kernel_noise(hr)                 # b, n, c, h, w
            self.optimizer.zero_grad()
            timer.tic()
            # forward
            ## train degradation encoder
            if epoch <= self.args.epochs_encoder:
                _, output_kernel, target_kernel = self.model_E_kernel(im_q=lr_same_kernel[:,0,...], im_k=lr_same_kernel[:,1,...])
                _, output_noise, target_noise = self.model_E_noise(im_q=lr_different_kernel[:,0,...], im_k=lr_different_kernel[:,1,...])
                # embedding(degradation representation of query), logits(negative sample predict), labels(for negative sample: 0 )
                #_, output, target = self.model.E(im_q=lr[:,0,...], im_k=lr[:,1,...])
                #print('embedding', _.shape)
                #print('output: ',output.shape)
                #print('target: ',target)
                loss_constrast_kernel = self.contrast_loss(output_kernel, target_kernel)
                loss_constrast_noise = self.contrast_loss(output_noise, target_noise)
                loss = loss_constrast_kernel + loss_constrast_noise
                losses_contrast.update(loss_constrast_kernel.item()+loss_constrast_noise.item())
                self.tb_logger_1.add_scalar( "L_kernel" , loss_constrast_kernel.item() , iteration)
                self.tb_logger_1.add_scalar( "L_noise" , loss_constrast_noise.item() , iteration)
                iteration+=1
            ## train the whole network
            else:
                sr, output_kernel,output_noise, target = self.model(lr_same_kernel,lr_different_kernel)
                #print('output: ',output.shape)
                #print('target: ',target)
                loss_SR = self.loss(sr, hr[:,0,...])
                loss_constrast_kernel = self.contrast_loss(output_kernel, target)
                loss_constrast_noise = self.contrast_loss(output_noise, target)
                loss = loss_constrast_kernel + loss_constrast_noise + loss_SR
                losses_sr.update(loss_SR.item())
                losses_contrast.update(loss_constrast_kernel.item()+loss_constrast_noise.item())
                self.tb_logger_1.add_scalar( "L_kernel" , loss_constrast_kernel.item() , iteration)
                self.tb_logger_1.add_scalar( "L_noise" , loss_constrast_noise.item() , iteration)
                self.tb_logger_2.add_scalar( "L_SR" , loss_SR.item() , iteration)
                iteration+=1
            # backward
            loss.backward()
            self.optimizer.step()
            timer.hold()
            if epoch <= self.args.epochs_encoder:
                if (iteration + 1) % self.args.print_every == 0:
                    self.ckp.write_log(
                        'Epoch: [{:03d}][{:04d}/{:04d}]\t'
                        'Loss [contrastive loss: {:.3f}]'.format(
                            epoch, int((iteration + 1) * self.args.batch_size), int(len(self.loader_train.dataset)),
                            losses_contrast.avg))
                    self.ckp.write_log(
                        'Epoch: [{:03d}][{:04d}/{:04d}]\t'
                        'Loss [contrastive loss: {:.3f}]\t'
                        'Time [{:.1f}s]'.format(
                            epoch, (iteration + 1) * self.args.batch_size, len(self.loader_train.dataset),
                            losses_contrast.avg,
                            round(timer.release())
                        ))
            else:
                if (iteration + 1) % self.args.print_every == 0:
                    self.ckp.write_log(
                        'Epoch: [{:04d}][{:04d}/{:04d}]\t'
                        'Loss [SR loss:{:.3f} | contrastive loss: {:.3f}]'.format(
                            epoch, int((iteration + 1) * self.batch_size), int(len(self.loader_train.dataset)),
                            losses_sr.avg, losses_contrast.avg))

        self.loss.end_log(len(self.loader_train))

        # save model
        #target = self.model.get_model()
        #model_dict = target.state_dict()
        #keys = list(model_dict.keys())
        model_dict =  self.model.state_dict()
        keys = list(model_dict)
        for key in keys:
            if 'E.encoder_k' in key or 'queue' in key:
                del model_dict[key]
        torch.save(
            model_dict,
            os.path.join(self.ckp.dir, 'model_new', 'model_{}.pt'.format(epoch))
        )
        # print(self.ckp.dir, 'model', 'model_{}.pt'.format(epoch))

    def test(self):
        self.ckp.write_log('\nEvaluation:')
        self.ckp.add_log(torch.zeros(1, len(self.scale)))
        if self.args.blur_type == 'iso_gaussian':
          dir = './experiment/blindsr_x' + str(int(self.scale[0])) + '_bicubic_iso'
        elif self.args.blur_type == 'aniso_gaussian':
          dir = './experiment/blindsr_x' + str(int(self.scale[0])) + '_bicubic_aniso'
        self.model.load_state_dict(torch.load(dir + '/model_new/model_' + str(self.args.resume) + '.pt'), strict=False)
        self.model.eval()
        timer_test = utility.timer()

        
        with torch.no_grad():
            for idx_scale, scale in enumerate(self.scale):
                #self.loader_test.dataset#.set_scale(idx_scale)
                eval_psnr = 0
                eval_ssim = 0

                degrade = util.SRMDPreprocessing(
                    self.scale[0],
                    kernel_size=self.args.blur_kernel,
                    blur_type=self.args.blur_type,
                    sig=self.args.sig,
                    lambda_1=self.args.lambda_1,
                    lambda_2=self.args.lambda_2,
                    theta=self.args.theta,
                    noise=self.args.noise
                )

                #for idx_img, (hr, filename, _) in enumerate(self.loader_test):
                for idx_img, (hr,filename) in enumerate(self.loader_test):
                    hr = hr.cuda()                      # b, 1, c, h, w
                    hr = self.crop_border(hr, scale)
                    hr = hr[:,:,[2,1,0],...]
                    hr = hr*255
                    lr, _ = degrade(hr, random=False)   # b, 1, c, h, w
                    #cv2.imwrite("test_lr.png", np.transpose(lr[0,0,[2, 1, 0],...].cpu().numpy(), (1, 2, 0))*255)
                    #cv2.imwrite(dir+filename[0]+"_lr.png", np.transpose(lr[0,0,...].cpu().numpy(), (1, 2, 0)))
                    hr = hr[:, 0, ...]                  # b, c, h, w
                    # inference
                    timer_test.tic()
                    sr = self.model(lr[:, 0, ...], lr[:, 0, ...])
                    
                    timer_test.hold()

                    sr = utility.quantize(sr, self.args.rgb_range)
                    hr = utility.quantize(hr, self.args.rgb_range)
                    print(self.args.rgb_range)
                    # metrics
                    eval_psnr += utility.calc_psnr(
                        sr, hr, scale, self.args.rgb_range,
                        benchmark=True#self.loader_test.dataset.benchmark
                    )
                    eval_ssim += utility.calc_ssim(
                        sr, hr, scale,
                        benchmark=True#self.loader_test.dataset.benchmark
                    )

                    # save results
                    self.args.save_result = True
                    #if self.args.save_results:
                    save_list = [sr]
                    filename = filename[0]
                    filename = filename.split(".")[0]                     
                    #cv2.imwrite(filename+"_x"+str(scale)+".png",  np.transpose(sr[0,[2,1,0],...].cpu().numpy(), (1, 2, 0)))
                    self.ckp.save_results(filename, save_list, scale)
                #print("filename",filename)
                print("eval_psnr",eval_psnr)
                self.ckp.log[-1, idx_scale] = eval_psnr / len(self.loader_test)
                self.ckp.write_log(
                    '[Epoch {}---{} x{}]\tPSNR: {:.3f} SSIM: {:.4f}'.format(
                        self.args.resume,
                        self.args.data_test,
                        scale,
                        eval_psnr / len(self.loader_test),
                        eval_ssim / len(self.loader_test),
                    ))

    def crop_border(self, img_hr, scale):
        b, n, c, h, w = img_hr.size()

        img_hr = img_hr[:, :, :, :int(h//scale*scale), :int(w//scale*scale)]

        return img_hr

    def terminate(self):
        if self.args.test_only:
            self.test()
            return True
        else:
            epoch = self.scheduler.last_epoch + 1
            return epoch >= self.args.epochs_encoder + self.args.epochs_sr'''

#########################################
class GANLoss(nn.Module):
    """D outputs a [0,1] map of size of the input. This map is compared in a pixel-wise manner to 1/0 according to
    whether the input is real (i.e. from the input image) or fake (i.e. from the Generator)"""

    def __init__(self, d_last_layer_size=48):
        super(GANLoss, self).__init__()
        # The loss function is applied after the pixel-wise comparison to the true label (0/1)
        self.loss = nn.L1Loss(reduction='mean')
        self.d_last_layer_size = d_last_layer_size
        # Make a shape[batch size,number of output layer,output layer size,output layer size]
        #d_last_layer_shape = [1, 8, d_last_layer_size, d_last_layer_size]
        # The two possible label maps are pre-prepared
        #self.label_tensor_fake = Variable(torch.zeros(d_last_layer_shape).cuda(), requires_grad=False)
        #self.label_tensor_real = Variable(torch.ones(d_last_layer_shape).cuda(), requires_grad=False)

    def forward(self, d_last_layer, is_d_input_real):
        # Determine label map according to whether current input to discriminator is real or fake
        [b,c,h,w]=d_last_layer.shape
        d_last_layer_shape = [1,8 , self.d_last_layer_size, self.d_last_layer_size]
        self.label_tensor_fake = torch.zeros((b,c,h,w), requires_grad=False).cuda()
        self.label_tensor_real = torch.ones((b,c,h,w), requires_grad=False).cuda()      
        label_tensor = self.label_tensor_real if is_d_input_real else self.label_tensor_fake
        # Compute the loss
        return self.loss(d_last_layer, label_tensor)


class L_TV(nn.Module):
    def __init__(self,TVLoss_weight=1):
        super(L_TV,self).__init__()
        self.TVLoss_weight = TVLoss_weight

    def forward(self,x):
        batch_size = x.size()[0]
        h_x = x.size()[2]
        w_x = x.size()[3]
        count_h =  (x.size()[2]-1) * x.size()[3]
        count_w = x.size()[2] * (x.size()[3] - 1)
        h_tv = torch.pow((x[:,:,1:,:]-x[:,:,:h_x-1,:]),2).sum()
        w_tv = torch.pow((x[:,:,:,1:]-x[:,:,:,:w_x-1]),2).sum()
        return self.TVLoss_weight*(h_tv/count_h+w_tv/count_w)/batch_size