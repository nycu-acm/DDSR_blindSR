import os
import utility
import torch
from decimal import Decimal
import torch.nn.functional as F
from utils import util
from tensorboardX import SummaryWriter
import csv
import lpips
import numpy as np
# DASR paper 
class Trainer():
    def __init__(self, args, loader, my_model, my_loss, ckp):
        self.args = args
        self.scale = args.scale

        self.ckp = ckp
        self.loader_train = loader.loader_train
        self.loader_test = loader.loader_test
        self.model = my_model
        self.model_E = torch.nn.DataParallel(self.model.get_model().E, range(self.args.n_GPUs))
        self.model_G = self.model.get_model().G
        self.loss = my_loss
        self.contrast_loss = torch.nn.CrossEntropyLoss().cuda()
        self.optimizer = utility.make_optimizer(args, self.model)
        self.scheduler = utility.make_scheduler(args, self.optimizer)
        tensorboard_folder = '/mnt/HDD3/yuan/DASR/tensorboard_dasr_cdsr_range/'
        self.tb_logger_1 = SummaryWriter(log_dir= os.path.join(tensorboard_folder , "loss_constrastive"))
        self.tb_logger_2 = SummaryWriter(log_dir= os.path.join(tensorboard_folder , "loss_sr"))
        self.loss_fn_alex = lpips.LPIPS(net='alex').cuda() # best forward scores
        if self.args.load != '.':
            self.optimizer.load_state_dict(
                torch.load(os.path.join(ckp.dir, 'optimizer.pt'))
            )
            for _ in range(len(ckp.log)): self.scheduler.step()
        self.iteration = 0
    def train(self):
        self.scheduler.step()
        self.loss.step()
        epoch = self.scheduler.last_epoch + 1

        # lr stepwise
        if epoch <= self.args.epochs_encoder:
            lr = self.args.lr_encoder * (self.args.gamma_encoder ** (epoch // self.args.lr_decay_encoder))
            for param_group in self.optimizer.param_groups:
                param_group['lr'] = lr
        else:
            lr = self.args.lr_sr * (self.args.gamma_sr ** ((epoch - self.args.epochs_encoder) // self.args.lr_decay_sr))
            for param_group in self.optimizer.param_groups:
                param_group['lr'] = lr

        self.ckp.write_log('[Epoch {}]\tLearning rate: {:.2e}'.format(epoch, Decimal(lr)))
        self.loss.start_log()
        self.model.train()
        ##
        degrade = util.SRMDPreprocessing(
            self.scale[0],
            kernel_size=self.args.blur_kernel,
            blur_type=self.args.blur_type,
            sig_min=self.args.sig_min,
            sig_max=self.args.sig_max,
            lambda_min=self.args.lambda_min,
            lambda_max=self.args.lambda_max,
            noise=self.args.noise
        )
        '''degrade = util.motion_SRMDPreprocessing(
            self.scale[0],
            kernel_size=self.args.blur_kernel,
            blur_type=self.args.blur_type,
            sig_min=self.args.sig_min,
            sig_max=self.args.sig_max,
            lambda_min=self.args.lambda_min,
            lambda_max=self.args.lambda_max,
            noise=self.args.noise
        )'''        
        ##

        timer = utility.timer()
        losses_contrast, losses_sr = utility.AverageMeter(), utility.AverageMeter()

        for batch, (hr, _, idx_scale) in enumerate(self.loader_train):
            hr = hr.cuda()                              # b, n, c, h, w
            lr, b_kernels = degrade(hr)                 # bn, c, h, w
            ## various blur :motion, gaussian,motion+gaussian
            '''hr_0 = hr[:,0,:3,...]
            hr_1 = hr[:,1,:3,...]
            hr_ = torch.stack((hr_0,hr_1),dim=1)            
            hr_0 = hr[:,0,3:6,...]
            hr_1 = hr[:,1,3:6,...]
            hr_blur = torch.stack((hr_0,hr_1),dim=1)
            hr_0 = hr[:,0,6:,...]
            hr_1 = hr[:,1,6:,...]
            hr_1 = torch.cat((hr_1[2:,...],hr_1[:2,...]), dim=0)
            hr_clean = torch.stack((hr_0,hr_1),dim=1)                       
            lr_blured_kernel, lr_no_blured, lr_blured_kernel_noise_1,lr_no_blured_noise,lr_blured_kernel_noise_2,lr_motion,lr_motion_noise_2,lr_blured_kernel_motion,lr_blured_kernel_motion_noise_2 = degrade(hr_,hr_blur,hr_clean)
            mode = np.random.randint((3))
            if mode == 0:
                lr = lr_blured_kernel_noise_1
                hr_pair = hr_clean
            elif mode == 1: 
                lr = lr_motion_noise_2
                hr_pair = hr_
            else:
                lr = lr_blured_kernel_motion_noise_2
                hr_pair = hr_'''
            
            ##
            self.optimizer.zero_grad()
            timer.tic()
            # forward
            ## train degradation encoder
            if epoch <= self.args.epochs_encoder:
                _, output, target = self.model_E(im_q=lr[:,0,...], im_k=lr[:,1,...])
                loss_constrast = self.contrast_loss(output, target)
                loss = loss_constrast
                self.tb_logger_1.add_scalar( "L_contrastive" , loss_constrast.item() , self.iteration)
                #self.tb_logger_1.add_scalar( "L_noise" , loss_constrast_noise.item() , batch)
                losses_contrast.update(loss_constrast.item())
            ## train the whole network
            else:
                sr, output, target = self.model(lr)
                loss_SR = self.loss(sr, hr[:,0,...])
                #loss_SR = self.loss(sr, hr_pair[:,0,...])
                loss_constrast = self.contrast_loss(output, target)
                loss = loss_constrast + loss_SR
                losses_sr.update(loss_SR.item())
                losses_contrast.update(loss_constrast.item())
                self.tb_logger_1.add_scalar( "L_contrastive" , loss_constrast.item() , self.iteration)
                self.tb_logger_2.add_scalar( "L_SR" , loss_SR.item() , self.iteration)
            # backward
            loss.backward()
            self.optimizer.step()
            timer.hold()
            self.iteration += 1
            if epoch <= self.args.epochs_encoder:
                if (batch + 1) % self.args.print_every == 0:
                    self.ckp.write_log(
                        'Epoch: [{:03d}][{:04d}/{:04d}]\t'
                        'Loss [contrastive loss: {:.3f}]\t'
                        'Time [{:.1f}s]'.format(
                            epoch, (batch + 1) * self.args.batch_size, len(self.loader_train.dataset),
                            losses_contrast.avg,
                            timer.release()
                        ))
            else:
                if (batch + 1) % self.args.print_every == 0:
                    self.ckp.write_log(
                        'Epoch: [{:04d}][{:04d}/{:04d}]\t'
                        'Loss [SR loss:{:.3f} | contrastive loss: {:.3f}]\t'
                        'Time [{:.1f}s]'.format(
                            epoch, (batch + 1) * self.args.batch_size, len(self.loader_train.dataset),
                            losses_sr.avg, losses_contrast.avg,
                            timer.release(),
                        ))

        self.loss.end_log(len(self.loader_train))

        # save model
        target = self.model.get_model()
        model_dict = target.state_dict()
        keys = list(model_dict.keys())
        for key in keys:
            if 'E.encoder_k' in key or 'queue' in key:
                del model_dict[key]
        torch.save(
            model_dict,
            ## os.path.join(self.ckp.dir, 'model', 'model_{}.pt'.format(epoch))
            os.path.join('/mnt/HDD8/yuan/', 'model_DASR_cdsr_range', 'model_{}.pt'.format(epoch))
        )

    def test(self):
        self.ckp.write_log('\nEvaluation:')
        self.ckp.add_log(torch.zeros(1, len(self.scale)))
        self.model.eval()

        timer_test = utility.timer()
        str_ = self.args.blur_type.split("_")[0]
        # ====================================================
        csv_path = '/mnt/HDD8/yuan/results_motion_blur02/extract_separate_evaluate.csv'
        with open(csv_path,'a') as f:
          writer = csv.writer(f)
          writer.writerow(['scale','noise','theta','lambda_1','lambda_2'])          
          writer.writerow([self.scale[0],self.args.noise,self.args.theta,self.args.lambda_1,self.args.lambda_2])
        with torch.no_grad():
            for idx_scale, scale in enumerate(self.scale):
                self.loader_test.dataset.set_scale(idx_scale)
                eval_psnr = 0
                eval_ssim = 0
                eval_lpips = 0
                degrade = util.SRMDPreprocessing(
                    self.scale[0],
                    kernel_size=self.args.blur_kernel,
                    blur_type=self.args.blur_type,
                    sig=self.args.sig,
                    lambda_1=self.args.lambda_1,
                    lambda_2=self.args.lambda_2,
                    theta=self.args.theta,
                    noise=self.args.noise
                )

                for idx_img, (hr, filename, _) in enumerate(self.loader_test):
                    hr = hr.cuda()                      # b, 1, c, h, w
                    hr = self.crop_border(hr, scale)
                    lr, kernel,_ = degrade(hr, random=False)   # b, 1, c, h, w
                    hr = hr[:, 0, ...]                  # b, c, h, w

                    # inference
                    timer_test.tic()
                    sr = self.model(lr[:, 0, ...])
                    timer_test.hold()
                    
                    sr = utility.quantize(sr, self.args.rgb_range)
                    hr = utility.quantize(hr, self.args.rgb_range)
                    d_lpips = self.loss_fn_alex(sr, hr)
                    eval_lpips += d_lpips.item()
                    # metrics
                    psnr_ = utility.calc_psnr(
                        sr, hr, scale, self.args.rgb_range,
                        benchmark=self.loader_test.dataset.benchmark
                    )
                    eval_psnr += psnr_
                    ssim_ = utility.calc_ssim(
                        sr, hr, scale,
                        benchmark=self.loader_test.dataset.benchmark
                    )
                    eval_ssim += ssim_
                    print(filename,'PSNR:{:.3f} SSIM{:.4f} LPIPS{:.4f}'.format(psnr_,ssim_,d_lpips.item()))
                    with open(csv_path,'a') as f:
                          writer = csv.writer(f)
                          writer.writerow([filename,psnr_,ssim_,d_lpips.item()])                   
                    # save results
                    if self.args.save_results:
                        save_list = [sr]
                        filename = filename[0]
                        self.ckp.save_results(filename, save_list, scale,self.args.data_test,self.args.lambda_1,self.args.lambda_2,self.args.theta,self.args.noise)
                self.ckp.save_results('kernel', [kernel], scale,self.args.data_test,self.args.lambda_1,self.args.lambda_2,self.args.theta,self.args.noise,False)
                with open(csv_path,'a') as f:
                   writer = csv.writer(f)
                   writer.writerow(['Average',eval_psnr/len(self.loader_test),eval_ssim/len(self.loader_test),eval_lpips/len(self.loader_test)])   
                self.ckp.log[-1, idx_scale] = eval_psnr / len(self.loader_test)
                self.ckp.write_log(
                    '[Epoch {}---{} x{}]\tPSNR: {:.3f} SSIM: {:.4f} LPIPS:{:.4f}'.format(
                        self.args.resume,
                        self.args.data_test,
                        scale,
                        eval_psnr / len(self.loader_test),
                        eval_ssim / len(self.loader_test),
                        eval_lpips/ len(self.loader_test)
                    ))
                print('kernel:[{},{}] noise level:[{}]'.format(self.args.lambda_1,self.args.lambda_2,self.args.noise))

    def crop_border(self, img_hr, scale):
        b, n, c, h, w = img_hr.size()

        img_hr = img_hr[:, :, :, :int(h//scale*scale), :int(w//scale*scale)]

        return img_hr

    def terminate(self):
        if self.args.test_only:
            self.test()
            return True
        else:
            epoch = self.scheduler.last_epoch + 1
            return epoch >= self.args.epochs_encoder + self.args.epochs_sr